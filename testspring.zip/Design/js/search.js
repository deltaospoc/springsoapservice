var currentScrollBarValue = 0;
function restrictScroll(e){
	e.preventDefault();
}

function callHide()
{
document.getElementById('popup').setAttribute("class", "demoVisible overlay");
document.addEventListener("wheel", restrictScroll, false);
document.body.style.overflow = 'hidden';
currentScrollBarValue = document.documentElement.scrollTop;
document.getElementById('popupWindow').offsetTop = document.getElementById('popupWindow').offsetTop + currentScrollBarValue;
}
function callClose()
{
document.getElementById('popup').setAttribute("class", "demoHidden overlay");
document.removeEventListener("wheel", restrictScroll, false);
document.body.style.overflow = 'visible';
document.getElementById('popupWindow').offsetTop = document.getElementById('popupWindow').offsetTop - currentScrollBarValue;

}