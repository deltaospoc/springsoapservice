function callHide()
{
document.getElementById('saran').setAttribute("class", "demo_visible overlay");

}
function callClose()
{

document.getElementById('saran').setAttribute("class", "demo_hidden overlay");
}